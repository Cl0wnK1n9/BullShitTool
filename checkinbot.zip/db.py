# sqlite 
import sqlite3

class database :
    def __init__(self, db):
        self.conn = sqlite3.connect(db)
        self.cur = self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS Credential (id INTEGER PRIMARY KEY AUTOINCREMENT, username text UNIQUE, password text, status INTEGER, deviceId text)")
        self.cur.execute("CREATE TABLE IF NOT EXISTS Log (id INTEGER PRIMARY KEY AUTOINCREMENT, status text)")
        self.conn.commit()
