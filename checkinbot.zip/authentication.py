import requests
import functions

class Auth:
    def __init__(self,username, password):
        self.host = "https://ddc.fis.vn/"
        self.username = username
        self.password = password
        self.logger = functions.loggery("test")
        self.CED = functions.CED("test")

    def login(self):
        url = self.host + "fis0/api/login"
        data = {
            'username': self.username,
            'password': self.password,
            "buildNumber": "10770",
            "version": "1.39",
        }
        response = requests.post(url, data=data).json()
        if response["resultCode"] == -1:
            return False
        elif response["resultCode"] == 1:
            return response["data"]["token"]
        else:
            return False
    


            
    
    