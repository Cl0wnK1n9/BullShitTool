import requests 

class Action:
    def __init__(self, token, status, day=None, month=None, year=None):
        self.token = token
        self.status = status
        self.host = "https://ddc.fis.vn/"
    
    def checkIn(self, deviceID):
        url = self.host + "fis0/api/checkin_all"
        data =   {
            "deviceId": deviceID,
            "ssid": "FIS",
            "ipGateway": "10.15.178.1",
            "type": 0,
        }
        headers = {
            "Authorization": "Bearer " + self.token,
            "User-Agent": "okhttp/4.9.2",
            "Accept-Encoding": "gzip"
        }
        
        response = requests.post(url, json=data, headers=headers).json()
        return response

    def checkOut(self, deviceID):
        url = self.host + "fis0/api/auto_checkout"
        data =   {
            "deviceId": deviceID,
            "deviceName": "",
            "ssid": "FIS",
            "ipGateway": "10.15.178.1",
            "type": 0,
            "isCheckDevice": True,
        }
        headers = {
            "Authorization": "Bearer " + self.token,
            "User-Agent": "okhttp/4.9.2",
            "Accept-Encoding": "gzip"
        }
        response = requests.post(url, json=data, headers=headers).json()
        return response

    def checkDevice(self, deviceID):
        url = self.host + "fis0/api/check_device"
        headers = {
            "Authorization": "Bearer " + self.token,
            "User-Agent": "okhttp/4.9.2",
            "Accept-Encoding": "gzip",
            "deviceid": deviceID
        }
        response = requests.get(url, headers=headers).json()
        return response
    
    def getDevices(self, day, month, year):
        url = self.host + "fis0/api/get_day_detail"
        headers = {
            "Authorization": "Bearer " + self.token,
            "User-Agent": "okhttp/4.9.2",
            "Accept-Encoding": "gzip",
        }
        data = {
                "day":day,
                "month":month,
                "year":year
            }
        response = requests.get(url, params=data, headers=headers).json()
        print(response)
        if response["data"] != None:
            deviceID = response["data"]["checkin"]["checkinDevice"]["id"]
            message = self.checkDevice(deviceID)
            print(message["message"])
            if message["message"] == "Thiết bị đã đăng kí":
                return deviceID
            return False