import db
class CED :
    def __init__(self, systename):
        self.db = db.database(systename+".db")

    def CreateUser(self,username, password):
        print("Create user: %s"%username)
        # preapre statement query
        query = "INSERT INTO Credential (username, password, status) VALUES (?, ?, ?)"
        self.db.cur.execute(query, (username, password, 1))
        self.db.conn.commit()

    def UpdateUser(self,username, key, value):
        print("Update user: %s"%username)
        query = "UPDATE Credential SET " + key + " = ? WHERE username = ?"
        self.db.cur.execute(query, (value, username))
        self.db.conn.commit()

    def DeleteUser(self,username):
        print("Delete user: %s"%username)
        query = "DELETE FROM Credential WHERE username = ?"
        self.db.cur.execute(query, (username,))
        self.db.conn.commit()

    def GetAllUser(self):
        query = "SELECT * FROM Credential"
        self.db.cur.execute(query)
        return self.db.cur.fetchall()
    
    def getInfo(self,tp,username):
        print("Get data: %s"%username)
        query = "SELECT " + tp + " FROM Credential WHERE username = ?"
        self.db.cur.execute(query, (username,))
        return self.db.cur.fetchone()
    
class loggery :
    def __init__(self, systename):
        self.db = db.database(systename+".db")

    def addLog(self, status):
        print("Log: %s"%status)
        query = "INSERT INTO Log (status) VALUES (?)"
        self.db.cur.execute(query, (status,))
        self.db.conn.commit()

    def getLog(self, id):
        print("Get log: %s"%id)
        query = "SELECT * FROM Log"
        self.db.cur.execute(query)
        return self.db.cur.fetchall()
              
