import authentication, check, functions
import sys, datetime

# get parameter
# act = sys.argv[1]
def day_detail():
    # get current year and month
    year = datetime.datetime.now().year
    month = datetime.datetime.now().month
    return [month, year]

def AddUser(username, password):
    func = functions.CED("FIS_ISA")
    func.CreateUser(username, password)
    login_obj = authentication.Auth(username, password)
    response = login_obj.login()
    # get deviceID
    check_obj = check.Action(response,1)
    info = day_detail()
    for i in range(1, 32):
        deviceID = check_obj.getDevices(i,info[0], info[1])
        if deviceID:
            func.UpdateUser(username, "deviceId", deviceID)
            return True
    return False

    # return deviceID

def main(action):
    # AddUser("minhtc14", "Tgb@123456789")
    func = functions.CED("FIS_ISA")

    users = func.GetAllUser()
    for user in users:
        username = user[1]
        password = user[2]
        deviceID = user[4]
        login_obj = authentication.Auth(username, password)
        response = login_obj.login()


        check_obj = check.Action(response,1)
        if action == "checkin":
            print(check_obj.checkIn(deviceID))
        elif action == "checkout":
            print(check_obj.checkOut(deviceID))
        else:
            print("Invalid action")

if __name__ == "__main__":
    main("checkin")
    # AddUser("dungdm15", "PMY5w4vIxYEMkwLrr2EL")